// Full answer choices on dashboard.privateprep.com quiz results pages.
// The results page for a digital-content quiz assignment only shows the
// student's answer and the correct answer. The full choice list (A-D) is
// only rendered by the quiz-library preview at /quizzes/<id>/preview, and
// the results page carries no quiz id — only the quiz title. So: look the
// title up in the /quizzes index, fetch that quiz's preview, match its
// questions to the ones on this page by stem text, and inject the choices.

(() => {
  const onResultsPage = () =>
    /^\/students\/\d+\/digital_content_quiz_assignments\/[^/]+\/results/
      .test(location.pathname);

  const normalize = (el) =>
    (el ? el.textContent : "").replace(/\s+/g, " ").trim();

  // Matching key: textContent doesn't add spaces at <br>/<div> boundaries and
  // the two pages wrap the same content differently, so compare with all
  // whitespace removed.
  const key = (el) => (el ? el.textContent : "").replace(/\s+/g, "");

  const parseHTML = (text) =>
    new DOMParser().parseFromString(text, "text/html");

  async function fetchDoc(path) {
    try {
      const res = await fetch(path, { credentials: "same-origin" });
      if (!res.ok) return null;
      return parseHTML(await res.text());
    } catch {
      return null;
    }
  }

  // /quizzes lists every quiz; titles aren't unique in principle, so return
  // every id whose link text matches and let the caller verify by content.
  async function findQuizIds(title) {
    const doc = await fetchDoc("/quizzes");
    if (!doc) return [];
    const ids = [];
    for (const a of doc.querySelectorAll("a[href^='/quizzes/']")) {
      const m = a.getAttribute("href").match(/^\/quizzes\/(\d+)$/);
      if (m && normalize(a) === title && !ids.includes(m[1])) ids.push(m[1]);
    }
    return ids;
  }

  // Preview page -> [{stem, choices: [{letter, contentEl}]}]
  async function fetchPreviewQuestions(quizId) {
    const doc = await fetchDoc(`/quizzes/${quizId}/preview`);
    if (!doc) return null;
    const questions = [];
    for (const q of doc.querySelectorAll(".quiz-runner__question")) {
      const stem = q.querySelector(
        ".quiz-runner__question-body .quiz-rendered-content"
      );
      const choices = [...q.querySelectorAll(".quiz-runner__choice")].map(
        (c) => ({
          letter: normalize(c.querySelector(".quiz-runner__choice-bubble")),
          contentEl: c.querySelector(".quiz-runner__choice-content"),
        })
      );
      if (stem && choices.length) {
        questions.push({ stem: key(stem), choices });
      }
    }
    return questions.length ? questions : null;
  }

  function resultCards() {
    return [...document.querySelectorAll(
      "section.student-section .legacy-card[data-controller='quiz-content']"
    )].map((card) => {
      const dds = {};
      for (const dt of card.querySelectorAll("dl dt")) {
        const dd = dt.nextElementSibling;
        if (dd && dd.tagName === "DD") dds[normalize(dt)] = dd;
      }
      return {
        card,
        dl: card.querySelector("dl"),
        stem: key(card.querySelector(".quiz-rendered-content")),
        yourAnswer: key(dds["Your answer"]),
        correctAnswer: key(dds["Correct answer"]),
      };
    });
  }

  function injectChoices(result, question) {
    if (!result.dl || result.dl.querySelector(".diag-nav-choices")) return;
    const dt = document.createElement("dt");
    dt.textContent = "All choices";
    const dd = document.createElement("dd");
    dd.className = "diag-nav-choices";
    for (const choice of question.choices) {
      const text = key(choice.contentEl);
      const isCorrect = text === result.correctAnswer;
      const isYours = text === result.yourAnswer;
      const row = document.createElement("div");
      row.style.cssText =
        "display:flex;gap:8px;align-items:baseline;padding:2px 0;";
      const bubble = document.createElement("strong");
      bubble.textContent = choice.letter;
      bubble.style.cssText = "min-width:1.2em;";
      const content = document.createElement("span");
      content.className = "quiz-rendered-content";
      content.append(...[...choice.contentEl.childNodes].map((n) =>
        document.importNode(n, true)
      ));
      row.append(bubble, content);
      if (isCorrect) {
        row.style.color = "#146c43";
        row.append(" ✓");
      } else if (isYours) {
        row.style.color = "#b02a37";
        row.append(" ✗ (your answer)");
      }
      dd.append(row);
    }
    result.dl.append(dt, dd);
  }

  function addLibraryLink(quizId) {
    const header = document.querySelector("header.inline-header");
    if (!header || header.querySelector(".diag-nav-quiz-link")) return;
    const a = document.createElement("a");
    a.className = "small-button primary diag-nav-quiz-link";
    a.href = `/quizzes/${quizId}`;
    a.textContent = "View in Quiz Library";
    header.appendChild(a);
  }

  async function init() {
    if (!onResultsPage()) return;
    const title = normalize(
      document.querySelector("header.inline-header h1.title")
    );
    const results = resultCards();
    if (!title || !results.length) return;

    for (const quizId of await findQuizIds(title)) {
      const questions = await fetchPreviewQuestions(quizId);
      if (!questions) continue;
      const matches = results.map((r) =>
        questions.find((q) => q.stem === r.stem)
      );
      // Same title, wrong quiz would match no stems; require a majority.
      if (matches.filter(Boolean).length * 2 <= results.length) continue;
      results.forEach((r, i) => matches[i] && injectChoices(r, matches[i]));
      addLibraryLink(quizId);
      return;
    }
  }

  // The dashboard is a Turbo app: in-app navigation swaps the <body> without
  // a real page load, so content scripts don't re-run. turbo:load fires on
  // the document after every Turbo visit (and once on initial load).
  document.addEventListener("turbo:load", init);
  init();
})();
